1. main_module.py is the mail file. It calls other modules. 	
	Main Module takes user input. GUI should be combined here. 

2. extracting_module.py
	This is the data extracting module. 
	Responsible for establishing connections and managing them
3. mon_functions.py 
	This is where device data extracting functions are defined.
	These function can be modified / added new features later

4. processing_module
	This is the module prints the output to screen.
	In future this will also include sections to write data into files. 
	Basically output / file writing happens here. 